const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

app.post('/api/leads', async (req, res) => {
  const { name, email, phone, zip, generator_type, comments } = req.body;
  await pool.query(
    'INSERT INTO leads (name, email, phone, zip, generator_type, comments, status) VALUES ($1, $2, $3, $4, $5, $6, $7)',
    [name, email, phone, zip, generator_type, comments, 'New']
  );
  res.status(200).json({ message: 'Lead saved' });
});

app.get('/api/leads', async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM leads ORDER BY created_at DESC');
  res.json(rows);
});

app.put('/api/leads/:id', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  await pool.query('UPDATE leads SET status = $1 WHERE id = $2', [status, id]);
  res.status(200).json({ message: 'Status updated' });
});

app.listen(5000, () => console.log('Server running on port 5000'));
